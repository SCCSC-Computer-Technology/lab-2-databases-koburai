﻿namespace A_Waddell_CPT_206_A80S_Lab_2
{


    partial class CityDBDataSet
    {
    }
}

namespace A_Waddell_CPT_206_A80S_Lab_2.CityDBDataSetTableAdapters {
    
    
    public partial class CitiesTableAdapter {
    }
}
